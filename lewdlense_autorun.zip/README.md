# LewdLense

A custom adult video scraper and search engine built with FastAPI.

## Endpoints

- `/status` — Simple health check
- `/search/pornhub?q=...` — (Coming soon)
- `/search/xvideos?q=...` — (Coming soon)
- `/search/thumbzilla?q=...` — (Coming soon)
