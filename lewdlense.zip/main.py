from fastapi import FastAPI
from scrapers import pornhub, xvideos, thumbzilla

app = FastAPI(title="LewdLense")

@app.get("/status")
def status():
    return {"status": "LewdLense is live."}
