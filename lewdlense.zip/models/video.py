from pydantic import BaseModel

class VideoResult(BaseModel):
    title: str
    duration: str
    thumbnail_url: str
    video_url: str
